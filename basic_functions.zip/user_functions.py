import os
import requests
import openai

# Weather from WeatherAPI
def weather_info(city):
    key = os.getenv("WEATHER_API_KEY")
    url = f"https://api.weatherapi.com/v1/current.json?key={key}&q={city}&lang=ko"
    response = requests.get(url)
    data = response.json()
    return {
        'temperature': f"{data['current']['temp_c']}",
        'condition': data['current']['condition']['text'],
        'feelslike': f"{data['current']['feelslike_c']}",
        'humidity': f"{data['current']['humidity']}%",
        'wind_kph': f"{round(data['current']['wind_kph'] * 0.27778, 2)}m/s",
        'source': "WeatherAPI forecast",
    }

# Email sender
def send_email(to_email, subject, message):
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart

    smtp_server = 'smtp.gmail.com'
    smtp_port = 587
    smtp_username = os.getenv("SMTP_USERNAME")
    smtp_password = os.getenv("SMTP_PASSWORD")
    
    msg = MIMEMultipart()
    # msg['From'] = smtp_username
    msg['From'] = 'enkiluv@gmail.com'
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(message, 'plain'))

    try:
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(smtp_username, smtp_password[::-1])
        server.sendmail(smtp_username, to_email, msg.as_string())
        server.quit()
        return "Email sent successfully."
    except Exception as e:
        return f"Email sending failure: {str(e)}"

# Create image using DALL-E
def draw_picture(prompt, orientation="square", quality="standard"):
    api_key = os.environ.get('OPENAI_API_KEY', None)
    if not api_key:
        raise RuntimeError("OpenAI API key is missing.")
    client = openai.OpenAI(api_key=api_key)
    sizes = {
        'square': '1024x1024',
        'landscape': '1792x1024',
        'portrait': '1024x1792',
    }

    try:
        response = client.images.generate(
            model="dall-e-3",
            prompt=(
    f"I NEED to test how the tool works with simple prompts. DO NOT add any detail, just use it AS-IS: {prompt}. "
    "Draw the image in vertical (portrait) orientation. "
    "Make sure all subjects (people, objects, scenery) are standing straight up, facing upright, and NOT rotated, tilted, or sideways in any way. "
    "The content itself should be vertically aligned, not just the canvas size."),
            n=1,
        )
        url = response.data[0].url
        return f"![DALL-E Image]({url})"
    except:
        return f"Image generation error -- check DALL-E availability."

if __name__ == "__main__":
    print(weather_info())

